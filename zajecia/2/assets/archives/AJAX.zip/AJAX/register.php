<?php 
	echo "Dziękujemy za dołączenie się, " . $_POST["name"] . "!<br />";
	echo "Wiadomość e-mail z potwierdzeniem zostałaby wysłana na adres: " . $_POST["email"] . ", gdyby to była rzeczywista witryna.";
?>