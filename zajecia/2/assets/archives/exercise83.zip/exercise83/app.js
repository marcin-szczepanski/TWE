function main() {
    const x = "Hello world!";
    const result = run(x);
    console.log(x.lowerCase());
}

window.onload = main;
