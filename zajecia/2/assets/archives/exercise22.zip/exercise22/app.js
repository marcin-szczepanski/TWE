function main() {
    let a = 5;
    let b = 0;
    const result = divide(a, b);
    let x = 7;
    for (let i = 0; i < 3; i++) {
        a++;
        b--;
        console.log(i);
        x++;
    }
    x = x - 7;
    let tab = [];
    let tab2 = [
        {name: "Nazwa 1", color: "red", howMuch: 5},
        {name: "Nazwa 2", color: "green", howMuch: 1},
        {name: "Nazwa 3", color: "orange", howMuch: 3},
        {name: "Nazwa 4", color: "blue", howMuch: 7}
    ];
    debugowanie();
}

function divide(x, y) {
    return x/y;
}

function debugowanie() {
    console.log("Debugowanie");
    const y = 5;
}

window.onload = main;
