console.log("start");
const anArray = new Array(-1);
anArray.push("0");
console.log(anArray);

const width = 12;
console.log(width * height);

let list = ['element 1', 'Element 2'
'Element 3'];
console.log(list[0].upperCase());

width.toFixed(30);

const user = {
    first name: "Bartek",
    lastName: "Nowak",
    age: 25
}
console.log(user.age.tostring());
