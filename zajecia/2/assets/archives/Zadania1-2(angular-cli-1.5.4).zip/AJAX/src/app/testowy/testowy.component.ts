import { Component, OnInit, OnDestroy } from '@angular/core';
import { TestService } from '../test.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-testowy',
  templateUrl: './testowy.component.html',
  styleUrls: ['./testowy.component.css']
})
export class TestowyComponent implements OnInit, OnDestroy {

  private edited: Boolean = false;
  private characters: Array<Object> = [];
  private species: Array<String> = [];
  private form: Object = {
    name: '',
    species: '',
    gender: '',
    homeworld: ''
  };

  private subscriptions: Array<Subscription> = [];

  constructor(private testService: TestService) {}

  ngOnInit() {
    this.getData();
    this.getSpecies();
  }

  getData() {
    this.subscriptions.push(this.testService.getData().subscribe(
      data => { this.characters = data; },
      error => { alert('Something went wrong. Try again later.'); }
    ));
  }

  getSpecies() {
    this.subscriptions.push(this.testService.getSpecies().subscribe(
      data => { this.species = data; },
      error => { alert('Something went wrong. Try again later.'); }
    ));
  }

  sendData(form): void {
    if ((form['name'] === undefined) || (form['species'] === undefined) ||
        (form['gender'] === undefined) || (form['homeworld'] === undefined) ||
        (form['name'].trim().length === 0) || (form['species'].trim().length === 0) ||
        (form['gender'].trim().length === 0) || (form['homeworld'].trim().length === 0)) {
        alert('Elements of form cannot be empty!');
    } else {
      this.subscriptions.push(this.testService.postData(form).subscribe(
        data => { this.getData(); },
        error => { alert('Something went wrong. Try again later.'); }
      ));
    }
  }

  ngOnDestroy() {
    for (let i = 0; i < this.subscriptions.length; i++) {
      this.subscriptions[i].unsubscribe();
    }
  }

}
