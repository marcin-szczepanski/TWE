import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class TestService {

  private url: String = 'http://localhost:3000/';

  constructor(private httpClient: HttpClient) { }

  getSpecies(): Observable<any> {
    return this.httpClient.get(`${this.url}species`);
  }

  getData(): Observable<any> {
    return this.httpClient.get(`${this.url}characters`);
  }

  postData(body): Observable<any> {
    return this.httpClient.post(`${this.url}characters`, body);
  }

}
