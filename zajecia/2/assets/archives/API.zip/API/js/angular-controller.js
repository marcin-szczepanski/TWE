function BasketCtrl($scope) {
  $scope.description = 'pojedynczy';
  $scope.cost = 8;
  $scope.qty = 1;
}